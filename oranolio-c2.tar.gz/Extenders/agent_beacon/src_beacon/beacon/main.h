#pragma once

#include "Agent.h"

extern Agent* g_Agent;

void AgentMain(); 

void AgentClear(int method);