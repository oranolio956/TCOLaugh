#pragma once
#include "ApiLoader.h"
#include "utils.h"

void WaitMask(ULONG worktime, ULONG sleepTime, ULONG jitter);

void mySleep(ULONG ms);