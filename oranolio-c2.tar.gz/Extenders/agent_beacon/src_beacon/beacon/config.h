#pragma once

#if defined(BUILD_SVC)
char* getServiceName();
#endif

char* getProfile();

unsigned int getProfileSize();