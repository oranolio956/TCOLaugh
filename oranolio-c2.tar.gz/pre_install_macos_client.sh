# client
# https://brew.sh/
brew install make cmake openssl qt@6
